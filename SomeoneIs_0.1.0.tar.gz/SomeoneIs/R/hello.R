#' Adds "is" between two input
#'
#' blah blhablalh
#' @param fuuasbglkfabs
#' @param Look mama!
#' @param asdfnasdfjbsadlgk
#' @export
WhoIs <- function(x,y) {
  print(paste0(x," is ",y))
}